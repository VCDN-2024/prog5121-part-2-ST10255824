package LoginAndRegistrationPortal;

import javax.swing.*;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginAndRegistrationPortal {
    static Map<String, String[]> users = new HashMap<>();
    private static boolean loggedIn = false;

    public static void main(String[] args) {
        // Display welcome message
        showMessage("Welcome to EasyKanban");
        
        
        //Adapted from https://blog.vidursoft.com/2011/11/create-login-form-using-netbeans-ide.html

        // Perform login process
        performLogin();

        // After successful login, proceed with task management
        if (loggedIn) {
            manageTasks();
        }

        // Display closing message
        showMessage("Closing EasyKanban. Goodbye!");
        System.exit(0);
    }
//Start of user Login
    //Adapted from https://www.theserverside.com/blog/Coffee-Talk-Java-News-Stories-and-Opinions/Java-user-input-with-a-Swing-JOptionPane-example
    public static void performLogin() {
        while (!loggedIn) {
            String username = getInput("Enter username:");

            if (!users.containsKey(username)) {
                int option = confirmDialog("Username not found. Do you want to register?", "User not found");

                if (option == JOptionPane.YES_OPTION) {
                    registerUser();
                } else {
                    showMessage("Closing EasyKanban. Goodbye!");
                    System.exit(0);
                }
            } else {
                String password = getInput("Enter password:");
                String[] userDetails = users.get(username);

                if (userDetails[0].equals(password)) {
                    loggedIn = true;
                    showMessage("Login successful! Welcome, " + userDetails[1] + " " + userDetails[2] + "!");
                } else {
                    showMessage("Invalid password. Please try again.");
                }
            }
        }
    }
// Adapted from https://beginnersbook.com/2013/05/method-overloading/
    // Overloaded PerformLogin method for testing
    public static void performLogin(String username, String password) {
        if (users.containsKey(username)) {
            String[] userDetails = users.get(username);
            if (userDetails[0].equals(password)) {
                loggedIn = true;
                showMessage("Login successful! Welcome, " + userDetails[1] + " " + userDetails[2] + "!");
            } else {
                showMessage("Invalid password. Please try again.");
            }
        } else {
            showMessage("Username not found. Please register first.");
        }
    }
//Start of User Registration
    public static void registerUser() {
        showMessage("=== Registration ===");
//Gets information from user
        String firstName = getInput("Enter first name:");
        String lastName = getInput("Enter last name:");
        String username = getInput("Enter username:");
//if statements to check if infromation user entered meets requirements
        if (!checkUserName(username)) {
            showMessage("Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return;
        }

        if (users.containsKey(username)) {
            showMessage("Username already exists. Please choose another one.");
            return;
        }

        String password = getInput("Enter password:");

        if (!checkPasswordComplexity(password)) {
            showMessage("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return;
        }

        String[] userDetails = {password, firstName, lastName};
        users.put(username, userDetails);
        showMessage("Registration successful for username: " + username);
    }
// Adapted from https://beginnersbook.com/2013/05/method-overloading/
    // Overloaded registerUser method for testing
    public static void registerUser(String firstName, String lastName, String username, String password) {
        if (!checkUserName(username)) {
            throw new IllegalArgumentException("Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.");
        }

        if (users.containsKey(username)) {
            throw new IllegalArgumentException("Username already exists. Please choose another one.");
        }

        if (!checkPasswordComplexity(password)) {
            throw new IllegalArgumentException("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
        }

        String[] userDetails = {password, firstName, lastName};
        users.put(username, userDetails);
    }

    public static boolean checkUserName(String username) {
        // Check if username contains an underscore and is no more than 5 characters long
        return username.length() <= 5 && username.contains("_");
    }

    public static boolean checkPasswordComplexity(String password) {
        // Check if the password meets the complexity requirements
        Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }
//Beggining of code relating to Task requirement of Part2 
    public static void manageTasks() {
        //Adapted from https://stackoverflow.com/questions/8059259/creating-a-console-menu-for-user-to-make-a-selection
        //A numerical list is displayed asking user to pick 1 out of 3 options
        int choice;
        do {
            String[] options = {"Add tasks", "Show report - Coming Soon", "Quit"};
            choice = optionDialog("Select an option:", "EasyKanban Menu", options);

            switch (choice) {
                case 0:
                    addTasks();
                    break;
                case 1:
                    showMessage("Report feature is still in development. Coming Soon!");
                    break;
                case 2:
                    break; // Exit loop and end application
                default:
                    showMessage("Invalid option. Please choose again.");
            }
        } while (choice != 2);
    }
//Asks user to enter number if task that need to or have been completed
    public static void addTasks() {
        int numTasks = Integer.parseInt(getInput("Enter number of tasks to enter:"));

        for (int i = 1; i <= numTasks; i++) {
            addTask();
        }

        showMessage("Total Hours Across All Tasks: " + Task.returnTotalHours());
    }

    public static void addTask() {
        showMessage("=== Add Task ===");
//Ask user to enter The name of task and description
        String taskName = getInput("Enter Task Name:");
        String taskDescription = getInput("Enter Task Description:");

        // Validate task description length using Task class method
        Task task = new Task(taskName, taskDescription, "", "", 0, ""); // Placeholder for developer details and status

        if (!task.checkTaskDescription()) {
            showMessage("Please enter a task description of less than 50 characters");
            return;
        } else {
            showMessage("Task successfully captured");
        }
//Asks user for developrs details
        String developerFirstName = getInput("Enter Developer First Name:");
        String developerLastName = getInput("Enter Developer Last Name:");
        String taskDurationStr = getInput("Enter Task Duration (in hours):");
        double taskDuration = Double.parseDouble(taskDurationStr); // Assuming task duration as double for flexibility

        // Update task details with actual developer details and status
        task = new Task(taskName, taskDescription, developerFirstName, developerLastName, taskDuration, selectTaskStatus());

        // Display Task Details using Task class method
        showMessage(task.printTaskDetails());

        // Increment task number for the next task
        Task.incrementTaskNumber();
    }

    public static String selectTaskStatus() {
        String[] statusOptions = {"To Do", "Done", "Doing"};
        int statusChoice = optionDialog("Select Task Status:", "Task Status", statusOptions);
        return statusOptions[statusChoice];
    }

    // Methods to abstract JOptionPane for better testability
    public static String getInput(String message) {
        return JOptionPane.showInputDialog(message);
    }

    public static void showMessage(String message) {
        JOptionPane.showMessageDialog(null, message);
    }

    public static int confirmDialog(String message, String title) {
        return JOptionPane.showConfirmDialog(null, message, title, JOptionPane.YES_NO_OPTION);
    }

    public static int optionDialog(String message, String title, String[] options) {
        return JOptionPane.showOptionDialog(null, message, title,
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
    }

    // Getter for the users map (for testing purposes)
    public static Map<String, String[]> getUsers() {
        return users;
    }

    // Getter for the loggedIn flag (for testing purposes)
    public static boolean isLoggedIn() {
        return loggedIn;
    }

    // Setter for the loggedIn flag (for testing purposes)
    public static void setLoggedIn(boolean loggedIn) {
        LoginAndRegistrationPortal.loggedIn = loggedIn;
    }
}

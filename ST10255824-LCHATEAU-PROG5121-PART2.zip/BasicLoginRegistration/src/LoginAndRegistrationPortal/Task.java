package LoginAndRegistrationPortal;

public class Task {
    private String taskName;
    private String taskDescription;
    private String developerFirstName;
    private String developerLastName;
    private double taskDuration;
    private String taskStatus;
    private static int taskNumber = 0; // static to keep track of task numbers
    private static int totalHours = 0;

    public Task(String taskName, String taskDescription, String developerFirstName, String developerLastName, double taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.developerFirstName = developerFirstName;
        this.developerLastName = developerLastName;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        totalHours += taskDuration;
    }

    public boolean checkTaskDescription() {
        return this.taskDescription.length() <= 50;
    }

    public String createTaskID() {
        return taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerLastName.substring(developerLastName.length() - 3).toUpperCase();
    }

    public String printTaskDetails() {
        return "Task Status: " + this.taskStatus +
                "\nDeveloper Details: " + this.developerFirstName + " " + this.developerLastName +
                "\nTask Number: " + taskNumber +
                "\nTask Name: " + this.taskName +
                "\nTask Description: " + this.taskDescription +
                "\nTask ID: " + createTaskID() +
                "\nTask Duration: " + this.taskDuration + " hours";
    }

    public static int returnTotalHours() {
        return totalHours;
    }

    public static void incrementTaskNumber() {
        taskNumber++;
    }

    public static void setTaskNumber(int number) {
        taskNumber = number;
    }
}

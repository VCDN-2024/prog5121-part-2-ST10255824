package LoginAndRegistrationPortal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
// Adapted from https://netbeans.apache.org/tutorial/main/kb/docs/java/junit-intro/

public class LoginAndRegistrationPortalTest {

    private static Map<String, String[]> users;

    @BeforeEach
    void setUp() {
        users = LoginAndRegistrationPortal.getUsers();
        users.clear();
        String[] userDetails = {"password", "John", "Doe"};
        users.put("johndoe", userDetails);

        // Reset loggedIn status
        LoginAndRegistrationPortal.setLoggedIn(false);
        
        //Adapted from https://coderanch.com/t/582303/engineering/test-overloaded-methods-JUnit-test
    }

    @Test
    void testCheckTaskDescription_Success() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", "", 8, "");
        assertTrue(task.checkTaskDescription());
    }

    @Test
    void testCheckTaskDescription_Failure() {
        Task task = new Task("Login Feature", "Create a task description that exceeds fifty characters in length", "Robyn Harrison", "", 8, "");
        assertFalse(task.checkTaskDescription());
    }

    @Test
    void testCreateTaskID() {
        Task task = new Task("Login Feature", "Create Login to authenticate users", "Robyn Harrison", "", 8, "");
        assertEquals("LO:0:SON", task.createTaskID());
    }

    @Test
    void testTaskIDLoop() {
        String[] taskNames = {"Add Task Feature", "Create Feature", "Read Feature", "Update Feature", "Delete Feature"};
        String[] developerNames = {"Mike Smith", "Alice Bob", "Carol Danvers", "Eve Adam", "John Doe"};
        String[] expectedTaskIDs = {"AD:1:ITH", "CR:2:ERS", "RE:3:ERS", "UP:4:DAM", "DE:5:DOE"};

        for (int i = 0; i < taskNames.length; i++) {
            Task task = new Task(taskNames[i], "Short description", developerNames[i], "", 5, "");
            assertEquals(expectedTaskIDs[i], task.createTaskID());
            Task.incrementTaskNumber();
        }
    }

    @Test
    void testTotalHoursAccumulation() {
        Task.setTaskNumber(0);

        int[] durations = {10, 12, 55, 11, 1};
        for (int duration : durations) {
            Task task = new Task("Test Task", "Test description", "Developer", "", duration, "");
            Task.incrementTaskNumber();
        }

        assertEquals(89, Task.returnTotalHours());
    }

    @Test
    void testLoginProcess() {
        LoginAndRegistrationPortal.performLogin("johndoe", "password");
        assertTrue(LoginAndRegistrationPortal.isLoggedIn());
    }

    @Test
    void testRegistrationProcess() {
        LoginAndRegistrationPortal.registerUser("Jane", "Doe", "jane_d", "Password123!");
        assertTrue(users.containsKey("jane_d"));
    }

    @Test
    void testRegistrationProcess_InvalidUsername() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            LoginAndRegistrationPortal.registerUser("Jane", "Doe", "jane", "Password123!");
        });

        assertEquals("Username is not correctly formatted. Please ensure that your username contains an underscore and is no more than 5 characters in length.", exception.getMessage());
    }

    @Test
    void testRegistrationProcess_InvalidPassword() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            LoginAndRegistrationPortal.registerUser("Jane", "Doe", "jane_d", "password");
        });

        assertEquals("Password is not correctly formatted. Please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.", exception.getMessage());
    }
}

